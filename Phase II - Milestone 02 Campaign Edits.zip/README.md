# Dexter

> Web App for Managing Leads

## Setup

Update database Environment variables in .env file
Run command: php artisan migrate --seed

    This command will create the database as well as one admin user

* Campaigns can only be edited and updated from main page 